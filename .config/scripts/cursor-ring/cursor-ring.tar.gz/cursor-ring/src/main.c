/*
 * cursor-ring — Wayland cursor finder overlay
 *
 * Draws one or two animated shrinking rings at the cursor position.
 * All visual parameters are configurable via CLI flags.
 *
 * Build:  meson setup build && ninja -C build
 * Usage:  cursor-ring [OPTIONS]
 *
 * Dependencies: gtk4, gtk4-layer-shell
 */

#include <gtk/gtk.h>
#include <gtk4-layer-shell/gtk4-layer-shell.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ─── Defaults (all overridable via CLI) ─────────────────────────────────── */

#define DEFAULT_X            -1          /* -1 = use GDK pointer query       */
#define DEFAULT_Y            -1
#define DEFAULT_RINGS        1           /* 1 or 2                           */
#define DEFAULT_RADIUS       80.0        /* px, starting radius              */
#define DEFAULT_DURATION     600         /* ms, total animation time         */
#define DEFAULT_LINE_WIDTH   3.0         /* px, stroke width                 */
#define DEFAULT_COLOR_R      1.0         /* red                              */
#define DEFAULT_COLOR_G      0.2         /* green                            */
#define DEFAULT_COLOR_B      0.2         /* blue                             */
#define DEFAULT_COLOR_A      1.0         /* alpha at start                   */
#define RING2_DELAY_FRAC     0.25        /* second ring lags by 25% of dur   */
#define WINDOW_PADDING       20          /* extra px around ring             */

/* ─── Config struct ─────────────────────────────────────────────────────── */

typedef struct {
    int    cursor_x;
    int    cursor_y;
    int    rings;          /* 1 or 2                                         */
    double radius;         /* starting radius in px                          */
    int    duration_ms;    /* total anim duration in ms                      */
    double line_width;     /* stroke width in px                             */
    double r, g, b, a;    /* RGBA colour (a = peak alpha)                   */
} Config;

/* ─── App state ─────────────────────────────────────────────────────────── */

typedef struct {
    GtkWindow      *window;
    GtkDrawingArea *canvas;
    Config          cfg;
    gint64          start_us;   /* animation start, microseconds             */
    gboolean        started;
} AppState;

/* ─── Drawing ────────────────────────────────────────────────────────────── */

/*
 * Draw a single ring.
 * progress: 0.0 (just appeared, full radius) → 1.0 (collapsed, gone)
 */
static void
draw_ring (cairo_t *cr, double cx, double cy, const Config *cfg, double progress)
{
    double radius = cfg->radius * (1.0 - progress);
    double alpha  = cfg->a     * (1.0 - progress);

    if (radius < 0.5 || alpha < 0.01)
        return;

    cairo_set_line_width (cr, cfg->line_width);
    cairo_set_source_rgba (cr, cfg->r, cfg->g, cfg->b, alpha);
    cairo_arc (cr, cx, cy, radius, 0.0, 2.0 * G_PI);
    cairo_stroke (cr);
}

static void
on_draw (GtkDrawingArea *area, cairo_t *cr,
         int width, int height, gpointer user_data)
{
    AppState *state = user_data;
    (void) area;

    /* transparent background */
    cairo_set_operator (cr, CAIRO_OPERATOR_SOURCE);
    cairo_set_source_rgba (cr, 0.0, 0.0, 0.0, 0.0);
    cairo_paint (cr);
    cairo_set_operator (cr, CAIRO_OPERATOR_OVER);

    if (!state->started)
        return;

    gint64  now_us   = g_get_monotonic_time ();
    double  elapsed  = (double)(now_us - state->start_us) / 1000.0; /* ms */
    double  dur      = (double) state->cfg.duration_ms;

    /* Ring 1 — starts at t=0 */
    double p1 = CLAMP (elapsed / dur, 0.0, 1.0);
    draw_ring (cr, width / 2.0, height / 2.0, &state->cfg, p1);

    /* Ring 2 — delayed start */
    if (state->cfg.rings >= 2) {
        double delay  = dur * RING2_DELAY_FRAC;
        double p2     = CLAMP ((elapsed - delay) / dur, 0.0, 1.0);
        if (elapsed >= delay)
            draw_ring (cr, width / 2.0, height / 2.0, &state->cfg, p2);
    }

    /* Quit once both rings have finished */
    double last_start = (state->cfg.rings >= 2) ? dur * RING2_DELAY_FRAC : 0.0;
    if (elapsed >= last_start + dur)
        gtk_window_destroy (state->window);
}

/* ─── Frame clock tick ───────────────────────────────────────────────────── */

static gboolean
on_tick (GtkWidget *widget, GdkFrameClock *clock, gpointer user_data)
{
    AppState *state = user_data;
    (void) clock;

    if (!state->started) {
        state->start_us = g_get_monotonic_time ();
        state->started  = TRUE;
    }

    gtk_widget_queue_draw (widget);
    return G_SOURCE_CONTINUE;
}

/* ─── Window setup ───────────────────────────────────────────────────────── */

static void
setup_window (AppState *state, GdkDisplay *display)
{
    Config *cfg = &state->cfg;

    int win_size = (int)(cfg->radius * 2.0) + WINDOW_PADDING * 2;

    GtkWidget *window = gtk_window_new ();
    state->window = GTK_WINDOW (window);

    /* Undecorated, transparent */
    gtk_window_set_decorated (GTK_WINDOW (window), FALSE);
    gtk_window_set_default_size (GTK_WINDOW (window), win_size, win_size);
    gtk_widget_set_opacity (window, 1.0);

    /* layer-shell: overlay layer, no keyboard grab, floating */
    gtk_layer_init_for_window (GTK_WINDOW (window));
    gtk_layer_set_layer        (GTK_WINDOW (window), GTK_LAYER_SHELL_LAYER_OVERLAY);
    gtk_layer_set_keyboard_mode(GTK_WINDOW (window), GTK_LAYER_SHELL_KEYBOARD_MODE_NONE);

    /* Place the window so its centre is at the cursor */
    int wx = cfg->cursor_x - win_size / 2;
    int wy = cfg->cursor_y - win_size / 2;
    gtk_layer_set_margin (GTK_WINDOW (window), GTK_LAYER_SHELL_EDGE_LEFT,   wx);
    gtk_layer_set_margin (GTK_WINDOW (window), GTK_LAYER_SHELL_EDGE_TOP,    wy);
    gtk_layer_set_anchor (GTK_WINDOW (window), GTK_LAYER_SHELL_EDGE_LEFT,   TRUE);
    gtk_layer_set_anchor (GTK_WINDOW (window), GTK_LAYER_SHELL_EDGE_TOP,    TRUE);
    gtk_layer_set_anchor (GTK_WINDOW (window), GTK_LAYER_SHELL_EDGE_RIGHT,  FALSE);
    gtk_layer_set_anchor (GTK_WINDOW (window), GTK_LAYER_SHELL_EDGE_BOTTOM, FALSE);

    /* Exclusive zone = 0: don't push other surfaces */
    gtk_layer_set_exclusive_zone (GTK_WINDOW (window), 0);

    /* Drawing area */
    GtkWidget *canvas = gtk_drawing_area_new ();
    state->canvas = GTK_DRAWING_AREA (canvas);
    gtk_drawing_area_set_draw_func (GTK_DRAWING_AREA (canvas), on_draw, state, NULL);
    gtk_window_set_child (GTK_WINDOW (window), canvas);

    /* Input passthrough — clicks go through to the app below */
    gtk_widget_set_can_target  (window, FALSE);
    gtk_widget_set_can_focus   (window, FALSE);
    gtk_widget_set_focusable   (window, FALSE);

    /* Tick for animation */
    gtk_widget_add_tick_callback (canvas, on_tick, state, NULL);

    gtk_window_present (GTK_WINDOW (window));
    (void) display;
}

/* ─── Cursor position auto-detection ────────────────────────────────────── */

/*
 * Run a shell command, read first line of stdout into buf.
 * Returns TRUE on success (non-empty output).
 */
static gboolean
run_command (const char *cmd, char *buf, size_t bufsz)
{
    FILE *fp = popen (cmd, "r");
    if (!fp) return FALSE;

    gboolean ok = (fgets (buf, (int) bufsz, fp) != NULL && buf[0] != '\0');
    pclose (fp);

    /* strip trailing newline/whitespace */
    if (ok) {
        size_t len = strlen (buf);
        while (len > 0 && (buf[len-1] == '\n' || buf[len-1] == '\r' || buf[len-1] == ' '))
            buf[--len] = '\0';
    }
    return ok;
}

/*
 * Try Hyprland: hyprctl cursorpos  →  "X, Y"
 */
static gboolean
try_hyprland (int *x, int *y)
{
    if (!g_getenv ("HYPRLAND_INSTANCE_SIGNATURE"))
        return FALSE;

    char buf[64];
    if (!run_command ("hyprctl cursorpos 2>/dev/null", buf, sizeof buf))
        return FALSE;

    /* Format: "960, 540" */
    int xi, yi;
    if (sscanf (buf, "%d, %d", &xi, &yi) == 2) {
        *x = xi; *y = yi;
        return TRUE;
    }
    return FALSE;
}

/*
 * Try Sway / wlroots: wlrctl pointer position  →  "X Y"
 */
static gboolean
try_wlrctl (int *x, int *y)
{
    char buf[64];
    if (!run_command ("wlrctl pointer position 2>/dev/null", buf, sizeof buf))
        return FALSE;

    int xi, yi;
    if (sscanf (buf, "%d %d", &xi, &yi) == 2) {
        *x = xi; *y = yi;
        return TRUE;
    }
    return FALSE;
}

/*
 * Try KDE / GNOME via kdotool or xdotool (XWayland or X11).
 * xdotool getmouselocation  →  "x:N y:N screen:N window:N"
 */
static gboolean
try_xdotool (int *x, int *y)
{
    char buf[128];
    if (!run_command ("xdotool getmouselocation 2>/dev/null", buf, sizeof buf))
        return FALSE;

    int xi, yi;
    if (sscanf (buf, "x:%d y:%d", &xi, &yi) == 2) {
        *x = xi; *y = yi;
        return TRUE;
    }
    return FALSE;
}

/*
 * Try ydotool (uinput-based, works on pure Wayland).
 * ydotool getmouselocation  →  "x:N y:N"
 */
static gboolean
try_ydotool (int *x, int *y)
{
    char buf[128];
    if (!run_command ("ydotool getmouselocation 2>/dev/null", buf, sizeof buf))
        return FALSE;

    int xi, yi;
    if (sscanf (buf, "x:%d y:%d", &xi, &yi) == 2) {
        *x = xi; *y = yi;
        return TRUE;
    }
    return FALSE;
}

/*
 * GDK fallback: only works if the pointer happens to be over an existing
 * GDK surface (unlikely for us, but worth trying before monitor-centre).
 */
static gboolean
try_gdk (int *x, int *y, GdkDisplay *display)
{
    GdkSeat    *seat    = gdk_display_get_default_seat (display);
    GdkDevice  *pointer = gdk_seat_get_pointer (seat);
    double      dx = 0, dy = 0;
    GdkSurface *surface = gdk_device_get_surface_at_position (pointer, &dx, &dy);
    if (surface) {
        *x = (int) dx;
        *y = (int) dy;
        return TRUE;
    }
    return FALSE;
}

/*
 * Last resort: centre of the primary monitor.
 */
static void
fallback_monitor_centre (int *x, int *y, GdkDisplay *display)
{
    GListModel   *monitors = gdk_display_get_monitors (display);
    GdkMonitor   *mon      = g_list_model_get_item (monitors, 0);
    GdkRectangle  geom;
    gdk_monitor_get_geometry (mon, &geom);
    *x = geom.x + geom.width  / 2;
    *y = geom.y + geom.height / 2;
    g_object_unref (mon);
    g_printerr ("cursor-ring: could not detect cursor position; "
                "using monitor centre (%d, %d)\n", *x, *y);
}

static void
resolve_cursor_position (Config *cfg, GdkDisplay *display)
{
    if (cfg->cursor_x >= 0 && cfg->cursor_y >= 0)
        return;   /* explicitly provided on CLI — trust it */

    int x = 0, y = 0;

    if (try_hyprland (&x, &y))   goto done;
    if (try_wlrctl   (&x, &y))   goto done;
    if (try_ydotool  (&x, &y))   goto done;
    if (try_xdotool  (&x, &y))   goto done;
    if (try_gdk      (&x, &y, display)) goto done;

    fallback_monitor_centre (&x, &y, display);

done:
    cfg->cursor_x = x;
    cfg->cursor_y = y;
}

/* ─── CLI parsing ────────────────────────────────────────────────────────── */

static void
print_usage (const char *argv0)
{
    fprintf (stderr,
        "Usage: %s [OPTIONS]\n"
        "\n"
        "Options:\n"
        "  --x <int>          Cursor X position (default: auto-detect)\n"
        "  --y <int>          Cursor Y position (default: auto-detect)\n"
        "  --rings <1|2>      Number of rings (default: %d)\n"
        "  --radius <float>   Starting radius in px (default: %.0f)\n"
        "  --duration <int>   Animation duration in ms (default: %d)\n"
        "  --linewidth <f>    Stroke width in px (default: %.1f)\n"
        "  --color <hex>      Ring colour as #RRGGBB or #RRGGBBAA (default: #FF3333FF)\n"
        "  --help             Show this help\n"
        "\n"
        "Cursor position is auto-detected (Hyprland, wlrctl, ydotool, xdotool).\n"
        "Override with --x / --y if needed.\n"
        "\n"
        "Examples:\n"
        "  cursor-ring\n"
        "  cursor-ring --rings 2 --radius 100 --duration 800 --color '#00AAFF'\n"
        "  cursor-ring --linewidth 5 --color '#FF6600CC'\n",
        argv0,
        DEFAULT_RINGS, DEFAULT_RADIUS, DEFAULT_DURATION, DEFAULT_LINE_WIDTH);
}

/*
 * Parse #RRGGBB or #RRGGBBAA hex colour.
 * Returns FALSE on parse error.
 */
static gboolean
parse_hex_color (const char *hex, double *r, double *g, double *b, double *a)
{
    if (!hex || hex[0] != '#') return FALSE;
    hex++;   /* skip '#' */

    unsigned int ri, gi, bi, ai = 255;
    int matched = 0;

    if (strlen (hex) == 8)
        matched = sscanf (hex, "%02x%02x%02x%02x", &ri, &gi, &bi, &ai);
    else if (strlen (hex) == 6)
        matched = sscanf (hex, "%02x%02x%02x", &ri, &gi, &bi);

    if (matched < 3) return FALSE;

    *r = ri / 255.0;
    *g = gi / 255.0;
    *b = bi / 255.0;
    *a = ai / 255.0;
    return TRUE;
}

static gboolean
parse_args (int argc, char **argv, Config *cfg)
{
    /* set defaults */
    cfg->cursor_x    = DEFAULT_X;
    cfg->cursor_y    = DEFAULT_Y;
    cfg->rings       = DEFAULT_RINGS;
    cfg->radius      = DEFAULT_RADIUS;
    cfg->duration_ms = DEFAULT_DURATION;
    cfg->line_width  = DEFAULT_LINE_WIDTH;
    cfg->r           = DEFAULT_COLOR_R;
    cfg->g           = DEFAULT_COLOR_G;
    cfg->b           = DEFAULT_COLOR_B;
    cfg->a           = DEFAULT_COLOR_A;

    for (int i = 1; i < argc; i++) {
        if (strcmp (argv[i], "--help") == 0 || strcmp (argv[i], "-h") == 0) {
            print_usage (argv[0]);
            return FALSE;
        }
#define NEED_NEXT() \
    if (i + 1 >= argc) { fprintf(stderr, "Missing value for %s\n", argv[i]); return FALSE; } \
    i++

        else if (strcmp (argv[i], "--x")         == 0) { NEED_NEXT(); cfg->cursor_x    = atoi (argv[i]); }
        else if (strcmp (argv[i], "--y")         == 0) { NEED_NEXT(); cfg->cursor_y    = atoi (argv[i]); }
        else if (strcmp (argv[i], "--rings")     == 0) { NEED_NEXT(); cfg->rings       = CLAMP(atoi(argv[i]), 1, 2); }
        else if (strcmp (argv[i], "--radius")    == 0) { NEED_NEXT(); cfg->radius      = atof (argv[i]); }
        else if (strcmp (argv[i], "--duration")  == 0) { NEED_NEXT(); cfg->duration_ms = atoi (argv[i]); }
        else if (strcmp (argv[i], "--linewidth") == 0) { NEED_NEXT(); cfg->line_width  = atof (argv[i]); }
        else if (strcmp (argv[i], "--color")     == 0) {
            NEED_NEXT();
            if (!parse_hex_color (argv[i], &cfg->r, &cfg->g, &cfg->b, &cfg->a)) {
                fprintf (stderr, "Bad color '%s'. Use #RRGGBB or #RRGGBBAA\n", argv[i]);
                return FALSE;
            }
        }
        else {
            fprintf (stderr, "Unknown option: %s\n", argv[i]);
            print_usage (argv[0]);
            return FALSE;
        }

#undef NEED_NEXT
    }
    return TRUE;
}

/* ─── GTK activate ───────────────────────────────────────────────────────── */

static AppState g_state;   /* single global instance */

static void
on_activate (GtkApplication *app, gpointer user_data)
{
    (void) user_data;

    GdkDisplay *display = gdk_display_get_default ();
    resolve_cursor_position (&g_state.cfg, display);

    g_state.window  = NULL;
    g_state.started = FALSE;

    setup_window (&g_state, display);
}

/* ─── main ───────────────────────────────────────────────────────────────── */

int main (int argc, char **argv)
{
    /* Parse our own flags before GTK sees them */
    if (!parse_args (argc, argv, &g_state.cfg))
        return 1;

    GtkApplication *app = gtk_application_new ("com.example.cursor-ring",
                                               G_APPLICATION_DEFAULT_FLAGS);
    g_signal_connect (app, "activate", G_CALLBACK (on_activate), NULL);

    /* Pass no args to GTK so it doesn't choke on our custom flags */
    int    fake_argc = 1;
    char  *fake_argv[] = { argv[0], NULL };
    int    status = g_application_run (G_APPLICATION (app), fake_argc, fake_argv);

    g_object_unref (app);
    return status;
}
